const { img } = require("./pagina2");


const imgs = document.getElementById(img);
